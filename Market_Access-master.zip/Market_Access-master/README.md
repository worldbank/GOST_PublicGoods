*** For full readme, see the Wiki page ***
